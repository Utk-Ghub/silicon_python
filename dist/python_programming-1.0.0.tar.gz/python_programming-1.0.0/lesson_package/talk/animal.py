from lesson_package.tools import utils

def sing():
    return '##fal;sakdjfalskdafj'

def cry():
    return utils.say_twice('fas;ldkjfalsfdkjaw')