from setuptools import setup

setup(
    name='python_programming',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='',
    license='Free',
    author='author',
    author_email='',
    description='Sample package'
)
